import { useEffect, useRef, useState } from "react";

type Role = "user" | "assistant";
interface Message {
  role: Role;
  content: string | object | any[];
}

interface VocItem {
  voc_id: number;
  title: string;
  type: string;
  request_lv1: string;
  request_lv2: string;
  request_date: string | null;
  completed_at: string | null;
  first_response_at: string | null;
  updated_deploy_at: string | null;
  channel: string | null;
  requestor_email: string | null;
  request_description: string | null;
  response_description: string | null;
  status: string;
}

/* -------- 판별/유틸 -------- */
const isVocObject = (d: any): d is VocItem =>
  d && typeof d === "object" && "voc_id" in d;

const isVocArray = (d: any): d is VocItem[] =>
  Array.isArray(d) && d.length > 0 && isVocObject(d[0]);

const pretty = (o: any) => {
  try {
    return JSON.stringify(o, null, 2);
  } catch {
    return String(o);
  }
};

/* -------- UI -------- */
function Bubble({ role, children }: { role: Role; children: React.ReactNode }) {
  const isUser = role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={[
          "max-w-[80%] rounded-2xl px-4 py-3 shadow-sm border",
          isUser ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-900",
        ].join(" ")}
      >
        <div className="text-xs mb-1 opacity-80">{isUser ? "나" : "AI"}</div>
        <div className="whitespace-pre-wrap">{children}</div>
      </div>
    </div>
  );
}

function VocCard({ voc }: { voc: VocItem }) {
  return (
    <div className="p-4 bg-white rounded-xl shadow border w-full">
      <div className="flex items-start justify-between gap-3">
        <h3 className="font-semibold text-lg">{voc.title ?? "(제목 없음)"}</h3>
        <span className="text-xs px-2 py-1 rounded-full bg-gray-100 border text-gray-600">
          #{voc.voc_id}
        </span>
      </div>

      {/* 🔽 여기 부분 수정 */}
      <div className="mt-2 flex flex-wrap gap-2 text-xs">
        {voc.type && (
          <span className="px-2 py-1 rounded-full bg-purple-100 text-purple-700 border">
            {voc.type}
          </span>
        )}
        {voc.channel && (
          <span className="px-2 py-1 rounded-full bg-blue-100 text-blue-700 border">
            {voc.channel}
          </span>
        )}
        {voc.request_lv1 && (
          <span className="px-2 py-1 rounded-full bg-green-100 text-green-700 border">
            {voc.request_lv1}
          </span>
        )}
        {voc.request_lv2 && (
          <span className="px-2 py-1 rounded-full bg-yellow-100 text-yellow-700 border">
            {voc.request_lv2}
          </span>
        )}
      </div>
      {/* 🔼 여기 부분 수정 끝 */}

      <div className="mt-3">
        <div className="text-sm font-medium text-gray-700">요청</div>
        <div className="mt-1 p-3 bg-gray-50 rounded-lg border text-gray-800 whitespace-pre-wrap">
          {voc.request_description ?? "—"}
        </div>
      </div>

      {voc.response_description && (
        <div className="mt-3">
          <div className="text-sm font-medium text-gray-700">응답</div>
          <div className="mt-1 p-3 bg-green-50 rounded-lg border text-gray-800 whitespace-pre-wrap">
            {voc.response_description}
          </div>
        </div>
      )}

      <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-gray-600">
        <div>상태: <span className="font-medium">{voc.status}</span></div>
        <div>요청일: {voc.request_date ?? "—"}</div>
        <div>초응답: {voc.first_response_at ?? "—"}</div>
        <div>완료일: {voc.completed_at ?? "—"}</div>
        {voc.requestor_email && (
          <div className="col-span-2 truncate">요청자: {voc.requestor_email}</div>
        )}
      </div>
    </div>
  );
}


/* -------- 메인 -------- */
export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "메세지를 입력하시면 원하시는 조건의 VoC를 보여드리겠습니다!" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    setMessages((prev) => [...prev, { role: "user", content: input }]);
    const text = input;
    setInput("");
    setLoading(true);

    try {
      // ✅ Vite 프록시 사용: 절대 URL 대신 상대경로
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }), // { content: "..." }
      });

      if (!res.ok) {
        // 에러 본문도 같이 달아줌 (디버깅 편하게)
        const errText = await res.text();
        throw new Error(`${res.status} ${res.statusText} :: ${errText}`);
      }

      const ct = res.headers.get("content-type") || "";
      let data: any;
      if (ct.includes("application/json")) data = await res.json();
      else data = await res.text();

      setMessages((prev) => [...prev, { role: "assistant", content: data }]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: `❌ 오류: ${e.message}` },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen w-screen flex items-center justify-center bg-gray-100">
      <div className="flex flex-col h-[90vh] w-full max-w-2xl bg-white border rounded-2xl shadow">
        {/* 헤더 */}
        <div className="px-4 py-3 border-b font-semibold">VOC Chat Console</div>

        {/* 대화 영역 */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((m, i) => {
            if (m.role === "assistant" && isVocArray(m.content)) {
              return (
                <div key={i} className="flex justify-start">
                  <div className="max-w-[80%] rounded-2xl px-4 py-3 shadow-sm border bg-white">
                    <div className="text-xs mb-2 opacity-80">AI</div>
                    <div className="space-y-3">
                      {m.content.map((v: VocItem) => (
                        <VocCard key={v.voc_id} voc={v} />
                      ))}
                    </div>
                  </div>
                </div>
              );
            }

            if (m.role === "assistant" && isVocObject(m.content)) {
              const v = m.content as VocItem;
              return (
                <div key={i} className="flex justify-start">
                  <div className="max-w-[80%] rounded-2xl px-4 py-3 shadow-sm border bg-white">
                    <div className="text-xs mb-2 opacity-80">AI</div>
                    <VocCard voc={v} />
                  </div>
                </div>
              );
            }

            const text = typeof m.content === "string" ? m.content : pretty(m.content);
            return (
              <Bubble key={i} role={m.role}>
                <pre className="whitespace-pre-wrap">{text}</pre>
              </Bubble>
            );
          })}

          {loading && (
            <div className="flex justify-start">
              <div className="max-w-[80%] rounded-2xl px-4 py-3 shadow-sm border bg-white text-gray-500">
                처리 중…
              </div>
            </div>
          )}

          <div ref={endRef} />
        </div>

        {/* 입력 영역 */}
        <div className="p-3 border-t bg-white">
          <div className="flex gap-2">
            <input
              className="flex-1 border rounded-lg px-3 py-2 text-black focus:outline-none focus:ring-2 focus:ring-blue-200"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="메시지를 입력하세요…"
            />
            <button
              onClick={sendMessage}
              disabled={loading}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg disabled:opacity-60"
            >
              보내기
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
